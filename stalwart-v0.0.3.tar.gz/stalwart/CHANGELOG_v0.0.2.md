# 🔧 Version 0.0.2 - Corrections CrashLoopBackOff

## 📋 Problème identifié

L'application était en **CrashLoopBackOff** infini. Le conteneur démarrait puis crashait immédiatement.

## 🛠️ Corrections apportées

### 1. **Volume mount path corrigé** ✅
**Avant** : `/opt/stalwart-mail/data`
**Maintenant** : `/opt/stalwart`

Stalwart Mail Server s'attend à trouver son répertoire de données à `/opt/stalwart` selon la documentation officielle.

### 2. **Variables d'environnement nettoyées** ✅
**Supprimé** :
- `STALWART_DB_TYPE`
- `STALWART_DB_HOST`
- `STALWART_DB_PORT`
- `STALWART_DB_NAME`
- `STALWART_DB_USER`
- `STALWART_DB_PASSWORD`
- `PUID`, `PGID`, `TZ`
- `STALWART_DOMAIN`

**Gardé** :
- `STALWART_ADMIN_PASSWORD` : Seule variable env standard
- `STALWART_HOSTNAME` : Configuration du hostname (ajouté)

**Raison** : Ces variables personnalisées n'existent pas dans l'image officielle `stalwartlabs/mail-server` et causaient probablement un crash au démarrage.

### 3. **SecurityContext ajusté** ✅
**Avant** :
```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  readOnlyRootFilesystem: false
```

**Maintenant** :
```yaml
securityContext:
  runAsNonRoot: false
  runAsUser: 0
```

**Raison** : Stalwart peut nécessiter des permissions root pour son initialisation et la liaison aux ports < 1024 (SMTP:25, IMAP:143, POP3:110).

### 4. **Probes modifiées** ✅
**Avant** : HTTP GET sur `/` (peut nécessiter authentification)
**Maintenant** : TCP Socket sur port 8080

**Délais augmentés** :
- `livenessProbe.initialDelaySeconds`: 30s → **60s**
- `readinessProbe.initialDelaySeconds`: 10s → **30s**
- `failureThreshold` augmentés pour plus de tolérance

**Raison** : Stalwart a besoin de temps pour son initialisation au premier démarrage (création de la base de données, génération des clés, etc.).

### 5. **Middleware PostgreSQL désactivé temporairement** ✅
Le middleware PostgreSQL a été commenté dans `OlaresManifest.yaml`.

**Raison** : Stalwart utilisera RocksDB/SQLite embarqué par défaut au premier démarrage. La configuration PostgreSQL peut être faite plus tard via l'interface web.

### 6. **Port JMAP ajouté** ✅
Ajout du port 443 pour le protocole JMAP (nouveau standard email).

## 📦 Nouveau package

**Fichier** : `/Users/user/Documents/Getlood/Olares/stalwart-v0.0.2.tar.gz`
**Taille** : 13 KB
**Version** : 0.0.2

## 🚀 Comment tester

### Option 1 : Upgrade de la version existante

Si vous avez déjà installé la v0.0.1 :

1. **Désinstaller** l'ancienne version dans Olares
2. **Attendre** que le pod soit complètement supprimé
3. **Uploader** `stalwart-v0.0.2.tar.gz`
4. **Installer** la nouvelle version

### Option 2 : Installation fraîche

1. **Uploader** `stalwart-v0.0.2.tar.gz` dans DevBox/Studio
2. **Installer** l'application
3. **Vérifier** les logs du pod :
   ```bash
   kubectl logs -n user-space-poudlardo <pod-name> -c stalwart
   ```

## 📊 Ce qui devrait se passer maintenant

1. ✅ Le pod démarre correctement
2. ✅ Stalwart s'auto-configure au premier lancement
3. ✅ Une base de données SQLite/RocksDB est créée dans `/opt/stalwart`
4. ✅ Un mot de passe admin est généré (celui de `values.yaml` ou aléatoire)
5. ✅ L'interface web devient accessible sur le port 8080

## 🔍 Vérification après installation

```bash
# Vérifier que le pod tourne
kubectl get pods -n user-space-poudlardo | grep stalwart

# Voir les logs (devrait afficher l'initialisation)
kubectl logs -n user-space-poudlardo <pod-name> -c stalwart

# Vérifier le status
kubectl describe pod -n user-space-poudlardo <pod-name>
```

## ⚠️ Si le problème persiste

Si le CrashLoopBackOff continue, **récupérez les logs du pod** :

```bash
kubectl logs -n user-space-poudlardo <pod-name> -c stalwart --previous
```

Cela montrera l'erreur exacte qui cause le crash.

## 📝 Notes importantes

1. **PostgreSQL** : La configuration PostgreSQL est commentée pour l'instant. Stalwart utilisera une base de données embarquée. Vous pourrez migrer vers PostgreSQL plus tard via l'interface web.

2. **Mot de passe admin** : Par défaut configuré à `changeme` dans `values.yaml`. **Changez-le immédiatement** après la première connexion !

3. **Premier accès** : Accédez à l'interface web via le Desktop Olares, entrée "Stalwart Mail".

4. **Configuration DNS** : N'oubliez pas de configurer vos enregistrements DNS (MX, SPF, DKIM, DMARC) avant d'utiliser le serveur mail en production.

---

**Testons cette version corrigée !** 🚀
