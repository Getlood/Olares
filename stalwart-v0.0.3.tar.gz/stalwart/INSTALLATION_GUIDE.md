# Guide d'installation de Stalwart Mail Server pour Olares

## 📋 Ce qui a été créé

Nous avons créé une structure complète de Helm Chart pour Stalwart Mail Server, compatible avec Olares. Voici les fichiers générés :

```
stalwart-mail/
├── Chart.yaml                    # Métadonnées Helm du chart
├── OlaresManifest.yaml          # Configuration spécifique Olares
├── values.yaml                   # Valeurs par défaut du déploiement
├── README.md                     # Documentation de l'application
├── .helmignore                   # Fichiers à ignorer lors du packaging
├── owners                        # Propriétaires GitHub du chart
├── templates/                    # Templates Kubernetes
│   ├── _helpers.tpl             # Helpers Helm réutilisables
│   ├── deployment.yaml          # Déploiement principal de l'application
│   ├── service.yaml             # Service exposant tous les ports mail
│   ├── serviceaccount.yaml      # ServiceAccount Kubernetes
│   ├── pvc.yaml                 # PersistentVolumeClaim pour le stockage
│   └── NOTES.txt                # Instructions post-installation
└── crds/                         # Custom Resource Definitions (vide pour l'instant)
```

## 🔑 Points clés de la configuration

### 1. **Ports mail configurés** (OlaresManifest.yaml:26-60)

Tous les ports standard des protocoles mail sont exposés :

- **SMTP (25)** : Réception de mails
- **SMTP Submission (587)** : Envoi authentifié
- **SMTPS (465)** : SMTP sécurisé
- **IMAP (143)** : Accès aux mails
- **IMAPS (993)** : IMAP sécurisé
- **POP3 (110)** : Récupération de mails
- **POP3S (995)** : POP3 sécurisé
- **HTTP (8080)** : Interface web d'administration

### 2. **Protocoles non-HTTP autorisés** (OlaresManifest.yaml:130-139)

La section `allowedOutboundPorts` permet à Stalwart de communiquer avec l'extérieur sur les ports mail :

```yaml
allowedOutboundPorts:
  - 25    # SMTP
  - 465   # SMTPS
  - 587   # SMTP Submission
  - 143   # IMAP
  - 993   # IMAPS
  - 110   # POP3
  - 995   # POP3S
  - 53    # DNS
```

### 3. **Base de données PostgreSQL**

Le chart utilise le middleware PostgreSQL fourni par Olares (OlaresManifest.yaml:66-71) :

```yaml
middleware:
  postgres:
    username: stalwart
    databases:
      - name: stalwart
        distributed: false
```

### 4. **Ressources système**

Les ressources sont configurées pour un serveur mail moderne :

- **Minimum** : 256 Mi RAM, 100m CPU, 1 Gi disque
- **Maximum** : 2 Gi RAM, 2000m CPU

## 📝 Prochaines étapes

### Option A : Test local avec DevBox (Recommandé)

1. **Installer DevBox** depuis le Market Olares
2. **Créer une nouvelle application** dans DevBox et importer votre chart
3. **Tester et debugger** dans l'environnement Olares réel
4. **Publier** une fois que tout fonctionne

### Option B : Soumission directe au Market

1. **Forker le repository officiel** : https://github.com/beclab/apps

2. **Copier votre chart** dans le repository forké :
   ```bash
   cp -r stalwart-mail/ /path/to/beclab/apps/
   ```

3. **Mettre à jour le fichier `owners`** avec votre username GitHub :
   ```bash
   echo "votre-username-github" > stalwart-mail/owners
   ```

4. **Créer un Draft PR** vers `beclab/apps:main` avec le titre :
   ```
   [NEW][stalwart][0.0.1] Add Stalwart Mail Server
   ```

5. **GitBot vérifiera automatiquement** votre PR

6. **Une fois mergé**, l'application apparaîtra dans le Market

## ⚙️ Personnalisations nécessaires

Avant de soumettre, vous devez ajuster :

### 1. **Fichier `owners`** (stalwart-mail/owners:1)
Remplacez `yourgithubusername` par votre vrai username GitHub

### 2. **Fichier `Chart.yaml`** (stalwart-mail/Chart.yaml:6)
Remplacez `yourgithubusername` par votre username

### 3. **Variables d'environnement Stalwart** (stalwart-mail/templates/deployment.yaml:40-56)
Vérifiez que les variables correspondent à la configuration de Stalwart. Consultez :
- https://stalw.art/docs/get-started

### 4. **Configuration du domaine par défaut** (stalwart-mail/values.yaml:65)
Ajustez selon vos besoins

### 5. **Image Docker**
Vérifiez que l'image `stalwartlabs/mail-server:v0.10.7` est compatible et testée

## 🔒 Sécurité

Assurez-vous de :

1. **Changer le mot de passe admin par défaut** immédiatement après installation
2. **Configurer TLS/SSL** pour tous les protocoles
3. **Activer les filtres anti-spam** et antivirus
4. **Configurer les enregistrements DNS** (SPF, DKIM, DMARC)

## 📚 Documentation consultée

- Structure des charts : `docs/developer/develop/package/chart.md`
- Spécification OlaresManifest : `docs/developer/develop/package/manifest.md`
- Process de soumission : `docs/developer/develop/submit/index.md`
- Tutorial : `docs/developer/develop/tutorial/note/create.md`

## 🐛 Debugging

Si vous rencontrez des problèmes :

1. Vérifiez les logs du pod :
   ```bash
   kubectl logs -n user-space-<username> <pod-name>
   ```

2. Vérifiez que tous les ports sont bien exposés :
   ```bash
   kubectl get svc -n user-space-<username>
   ```

3. Testez la connectivité aux ports mail :
   ```bash
   telnet your-olares-domain.com 25
   ```

## ❓ Questions fréquentes

**Q: Les ports 25, 587, etc. seront-ils accessibles depuis Internet ?**
R: Oui, grâce à la configuration `ports` et `addToTailscaleAcl: true` dans OlaresManifest.yaml. Les ports seront accessibles via votre domaine Olares.

**Q: Dois-je ouvrir des ports sur mon routeur ?**
R: Cela dépend de votre configuration réseau. Pour un serveur mail public, vous devrez probablement configurer le port forwarding sur votre routeur.

**Q: Comment configurer les DNS ?**
R: Consultez le fichier README.md pour des exemples de configuration DNS (MX, SPF, DKIM, DMARC).

---

**Bon développement ! 🚀**
