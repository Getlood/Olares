# Guide de dépannage - Stalwart Mail Server

## ❌ Erreur: "metadata.appid is required"

### Problème
```
Failed to upload chart stalwart.tar.gz
Failed to process package: chart repo service returned error status 400:
{"success":false,"message":"Failed to process package: chart validation failed:
failed to parse app info for validation: metadata.appid is required"}
```

### Cause
Le champ `metadata.appid` était manquant dans le fichier `OlaresManifest.yaml`.

### Solution ✅
Le champ `appid` a été ajouté dans `OlaresManifest.yaml` (ligne 6) :

```yaml
metadata:
  name: stalwart
  appid: e51f5a8f  # ← Ajouté
  title: Stalwart Mail Server
  description: Modern, secure & scalable mail server (IMAP, JMAP, SMTP)
  # ...
```

### Comment calculer l'appid

Pour les applications **communautaires** (non-système), l'`appid` est calculé comme suit :

```bash
# Prendre les 8 premiers caractères du hash MD5 du nom de l'app
echo -n "stalwart" | md5sum | cut -c1-8
# Résultat: e51f5a8f
```

Pour les applications **système**, l'`appid` est identique au `name`.

### Référence

D'après la documentation Olares (`docs/developer/concepts/application.md`) :

> "The application ID is derived as the first eight characters of the MD5 hash
> of the application name. For instance, if the application name is "hello",
> the application ID becomes "b1946ac9"."

Et dans le CRD Application (`framework/app-service/.olares/config/cluster/crds/app.bytetrade.io_applications.yaml`) :

```yaml
spec:
  appid:
    description: |-
      the unique id of the application
      for sys application appid equal name otherwise appid equal md5(name)[:8]
    type: string
```

## 📦 Comment packager le chart correctement

### Méthode 1: Avec Helm (recommandé)

```bash
cd stalwart-mail
helm package . -d ../
```

### Méthode 2: Avec le script fourni

```bash
cd stalwart-mail
./package.sh
```

### Méthode 3: Manuellement

```bash
cd /Users/user/Documents/Getlood/Olares
tar -czf stalwart.tar.gz \
    --exclude="stalwart-mail/.git" \
    --exclude="stalwart-mail/package.sh" \
    stalwart-mail/
```

## ✅ Checklist avant upload

Avant de ré-uploader votre chart, vérifiez que :

- [ ] `metadata.appid` est présent dans `OlaresManifest.yaml`
- [ ] `metadata.name` est cohérent avec le nom du dossier et `Chart.yaml`
- [ ] `metadata.version` correspond à `Chart.yaml`
- [ ] Tous les champs requis sont présents :
  - [ ] `olaresManifest.version`
  - [ ] `olaresManifest.type`
  - [ ] `metadata.name`
  - [ ] `metadata.appid`
  - [ ] `metadata.title`
  - [ ] `metadata.description`
  - [ ] `metadata.icon`
  - [ ] `metadata.version`
  - [ ] `entrances` (au moins 1)
  - [ ] `spec.versionName`
  - [ ] `spec.fullDescription`
  - [ ] `spec.developer`
  - [ ] `spec.supportArch`
  - [ ] `spec.requiredMemory`
  - [ ] `spec.requiredCpu`
  - [ ] `spec.limitedMemory`
  - [ ] `spec.limitedCpu`

## 🔍 Validation du manifest

Vous pouvez vérifier rapidement la présence de l'appid :

```bash
grep "appid:" stalwart-mail/OlaresManifest.yaml
# Devrait afficher: appid: e51f5a8f
```

## 🚀 Prochaines étapes

1. **Recréer le package** avec la correction :
   ```bash
   cd stalwart-mail
   ./package.sh
   ```

2. **Uploader le nouveau fichier** `.tar.gz` ou `.tgz` dans DevBox/Studio

3. **Tester l'installation** de l'application

## 📚 Ressources supplémentaires

- Documentation OlaresManifest : `docs/developer/develop/package/manifest.md`
- Concepts d'application : `docs/developer/concepts/application.md`
- CRD Application : `framework/app-service/.olares/config/cluster/crds/app.bytetrade.io_applications.yaml`

## 🆘 Autres erreurs courantes

### Port déjà utilisé

Si vous obtenez une erreur comme "port 25 already in use" :

1. Vérifiez qu'aucune autre application n'utilise ce port
2. Modifiez `exposePort` dans `OlaresManifest.yaml` si nécessaire

### Problèmes de permissions

Si l'app ne peut pas accéder aux données :

1. Vérifiez la section `permission:` dans `OlaresManifest.yaml`
2. Assurez-vous que `appData` et `appCache` sont activés

### Middleware PostgreSQL non disponible

Si la base de données n'est pas créée :

1. Vérifiez la section `middleware:` dans `OlaresManifest.yaml`
2. Assurez-vous que PostgreSQL est disponible dans votre cluster Olares

---

**Le problème a été corrigé ! Vous pouvez maintenant recréer le package et l'uploader.** ✅
