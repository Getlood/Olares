#!/bin/bash

# Script to package the Stalwart Mail Server Helm Chart for Olares

set -e  # Exit on error

CHART_NAME="stalwart"
CHART_DIR="."
OUTPUT_DIR="../"

echo "🔧 Packaging Stalwart Mail Server Chart..."
echo ""

# Validate Chart.yaml exists
if [ ! -f "Chart.yaml" ]; then
    echo "❌ Error: Chart.yaml not found in current directory"
    exit 1
fi

# Validate OlaresManifest.yaml exists
if [ ! -f "OlaresManifest.yaml" ]; then
    echo "❌ Error: OlaresManifest.yaml not found in current directory"
    exit 1
fi

# Check if appid is present in OlaresManifest.yaml
if ! grep -q "appid:" OlaresManifest.yaml; then
    echo "❌ Error: metadata.appid is missing in OlaresManifest.yaml"
    echo "   The appid should be: e51f5a8f (MD5 hash of 'stalwart' truncated to 8 chars)"
    exit 1
fi

echo "✅ Chart validation passed"
echo ""

# Package the chart using Helm (if helm is available)
if command -v helm &> /dev/null; then
    echo "📦 Using Helm to package the chart..."
    helm package "$CHART_DIR" -d "$OUTPUT_DIR"
    echo ""
    echo "✅ Chart packaged successfully with Helm!"
    echo "   Output: $OUTPUT_DIR${CHART_NAME}-*.tgz"
else
    echo "⚠️  Helm not found, creating tar.gz manually..."

    # Create tar.gz manually
    cd ..
    tar -czf "${CHART_NAME}.tar.gz" \
        --exclude="stalwart-mail/package.sh" \
        --exclude="stalwart-mail/.git" \
        --exclude="stalwart-mail/.gitignore" \
        "stalwart-mail/"

    cd - > /dev/null

    echo ""
    echo "✅ Chart packaged successfully!"
    echo "   Output: $OUTPUT_DIR${CHART_NAME}.tar.gz"
fi

echo ""
echo "📋 Next steps:"
echo "   1. Upload the generated .tar.gz/.tgz file to DevBox/Studio"
echo "   2. Or submit it to https://github.com/beclab/apps"
echo ""
echo "📝 Important notes:"
echo "   - metadata.appid: e51f5a8f (derived from MD5 of 'stalwart')"
echo "   - Chart version: 0.0.1"
echo "   - App version: 0.10.7"
echo ""
