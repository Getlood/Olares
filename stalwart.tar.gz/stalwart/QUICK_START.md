# 🚀 Démarrage rapide - Stalwart Mail Server

## ✅ Problèmes résolus !

### 1. Champ `metadata.appid` ajouté
```yaml
metadata:
  name: stalwart
  appid: e51f5a8f  # ← Calculé depuis MD5("stalwart")[:8]
```

### 2. Nom du dossier corrigé
- **Avant** : `stalwart-mail` ❌
- **Maintenant** : `stalwart` ✅
- Tous les noms sont maintenant cohérents !

## 📦 Créer le package corrigé

### Option 1 : Avec le script fourni (recommandé)

```bash
cd /Users/user/Documents/Getlood/Olares/stalwart
./package.sh
```

Le fichier `stalwart.tar.gz` sera créé dans le dossier parent.

### Option 2 : Avec Helm

```bash
cd /Users/user/Documents/Getlood/Olares/stalwart
helm package . -d ../
```

Le fichier `stalwart-0.0.1.tgz` sera créé dans le dossier parent.

### Option 3 : Manuellement

```bash
cd /Users/user/Documents/Getlood/Olares
tar -czf stalwart.tar.gz \
    --exclude="stalwart/.git" \
    --exclude="stalwart/package.sh" \
    stalwart/
```

## 📤 Uploader le chart

1. **Ouvrez DevBox/Studio** dans Olares
2. **Sélectionnez "Import Chart"** ou "Upload Custom Application"
3. **Uploadez le fichier** `stalwart.tar.gz` ou `stalwart-0.0.1.tgz`
4. **Attendez la validation** - Cette fois ça devrait fonctionner ! ✅

## 📋 Ce qui a été changé

| Élément | Avant | Maintenant |
|---------|-------|------------|
| Nom du dossier | `stalwart-mail` ❌ | `stalwart` ✅ |
| `OlaresManifest.yaml` ligne 6 | (manquant) | `appid: e51f5a8f` ✅ |

## 🔍 Vérification rapide

Pour confirmer que tout est correct :

```bash
# Vérifier l'appid
grep "appid:" stalwart/OlaresManifest.yaml
# Devrait afficher : appid: e51f5a8f

# Vérifier le nom
grep "name:" stalwart/Chart.yaml stalwart/OlaresManifest.yaml
# Les deux doivent afficher "stalwart"
```

## 📚 Fichiers disponibles

Votre chart contient maintenant :

```
stalwart/                         # Nom corrigé ! ✅
├── Chart.yaml                    # Métadonnées Helm ✓
├── OlaresManifest.yaml          # Config Olares avec appid ✅
├── values.yaml                   # Valeurs par défaut ✓
├── README.md                     # Documentation ✓
├── INSTALLATION_GUIDE.md         # Guide d'installation ✓
├── TROUBLESHOOTING.md            # Dépannage ✓
├── QUICK_START.md               # Ce fichier ✓
├── package.sh                    # Script de packaging ✓
├── .helmignore                   # Exclusions ✓
├── owners                        # Propriétaires GitHub ✓
└── templates/                    # Templates Kubernetes ✓
    ├── _helpers.tpl
    ├── deployment.yaml          # 8 ports mail + web
    ├── service.yaml
    ├── serviceaccount.yaml
    ├── pvc.yaml
    └── NOTES.txt
```

## ⚠️ N'oubliez pas avant la production

1. **Modifier `owners`** avec votre username GitHub réel
2. **Tester l'image Docker** `stalwartlabs/mail-server:v0.10.7`
3. **Configurer votre domaine** dans les settings après installation
4. **Configurer DNS** (MX, SPF, DKIM, DMARC)
5. **Changer le mot de passe admin** par défaut

## 🎯 Prochaines étapes après upload réussi

1. **Installer l'app** depuis le Market ou DevBox
2. **Accéder à l'interface web** via Olares Desktop
3. **Configurer le domaine mail**
4. **Créer les enregistrements DNS**
5. **Tester l'envoi/réception** d'emails

## 💡 Astuce

Pour éviter ce genre d'erreur à l'avenir, utilisez toujours cette commande pour calculer l'appid :

```bash
echo -n "nom-de-votre-app" | md5sum | cut -c1-8
```

---

**Tout est prêt ! Vous pouvez maintenant uploader votre chart corrigé.** 🎉
